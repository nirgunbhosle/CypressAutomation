1. first open the vs studio and in terminal write the below command to open cypress
    - node_modules\.bin\cypress open
2. click on E2E testing which is first option
3. select the chrome browser and click on open
4. Then find file names as nirgun.cy.js on opened chrome browser under spec section.
5. click on that file it will run the all test cases.